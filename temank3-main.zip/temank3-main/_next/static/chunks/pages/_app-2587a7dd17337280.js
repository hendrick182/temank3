(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[888], {
  6840: function(e, n, t) {
      (window.__NEXT_P = window.__NEXT_P || []).push(["/_app", function() {
          return t(4178)
      }
      ])
  },
  4178: function(e, n, t) {
      "use strict";
      t.r(n),
      t.d(n, {
          default: function() {
              return o
          }
      });
      var i = t(5893);
      t(3814);
      var s = t(9008)
        , a = t.n(s);
      function o(e) {
          let {Component: n, pageProps: t} = e;
          return (0,
          i.jsxs)(i.Fragment, {
              children: [(0,
              i.jsxs)(a(), {
                  children: [(0,
                  i.jsx)("meta", {
                      name: "description",
                      content: "TemanK3"
                  }), (0,
                  i.jsx)("meta", {
                      name: "author",
                      content: "Sandri Ranto"
                  }), (0,
                  i.jsx)("meta", {
                      name: "generator",
                      content: "Sancode"
                  }), (0,
                  i.jsx)("meta", {
                      name: "viewport",
                      content: "width=device-width, initial-scale=1, shrink-to-fit=no"
                  }), (0,
                  i.jsx)("link", {
                      rel: "shortcut icon",
                      href: "https://temank3.kemnaker.go.id/public/images/logo-kemnaker.png"
                  }), (0,
                  i.jsx)("link", {
                      rel: "apple-touch-icon",
                      sizes: "180x180",
                      href: "https://temank3.kemnaker.go.id/public/themes/website/asset/favicons/apple-touch-icon.png"
                  }), (0,
                  i.jsx)("link", {
                      rel: "icon",
                      type: "image/png",
                      sizes: "32x32",
                      href: "https://temank3.kemnaker.go.id/public/themes/website/asset/favicons/favicon-32x32.png"
                  }), (0,
                  i.jsx)("link", {
                      rel: "icon",
                      type: "image/png",
                      sizes: "16x16",
                      href: "https://temank3.kemnaker.go.id/public/themes/website/asset/favicons/favicon-16x16.png"
                  }), (0,
                  i.jsx)("link", {
                      rel: "mask-icon",
                      href: "https://temank3.kemnaker.go.id/public/themes/website/asset/favicons/safari-pinned-tab.svg",
                      color: "#2b5797"
                  }), (0,
                  i.jsx)("title", {
                      children: "Beranda TemanK3"
                  })]
              }), (0,
              i.jsx)(n, {
                  ...t
              })]
          })
      }
  },
  3814: function() {},
  9008: function(e, n, t) {
      e.exports = t(2636)
  }
}, function(e) {
  var n = function(n) {
      return e(e.s = n)
  };
  e.O(0, [774, 179], function() {
      return n(6840),
      n(6885)
  }),
  _N_E = e.O()
}
]);
