(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[73], {
  541: function(e, t, l) {
      (window.__NEXT_P = window.__NEXT_P || []).push(["/page/cek_qrcode/[code]", function() {
          return l(8841)
      }
      ])
  },
  8841: function(e, t, l) {
      "use strict";
      l.r(t),
      l.d(t, {
          __N_SSP: function() {
              return r
          },
          default: function() {
              return c
          }
      });
      var a = l(5893)
        , s = l(5788)
        , n = l(9583)
        , i = l(7294)
        , r = !0;
      function c(e) {
          var t, l;
          let {detail: r} = e
            , [c,o] = (0,
          i.useState)(!1)
            , d = null == r ? void 0 : r[0]
            , m = [{
              value: 1,
              label: "Januari"
          }, {
              value: 2,
              label: "Februari"
          }, {
              value: 3,
              label: "Maret"
          }, {
              value: 4,
              label: "April"
          }, {
              value: 5,
              label: "Mei"
          }, {
              value: 6,
              label: "Juni"
          }, {
              value: 7,
              label: "Juli"
          }, {
              value: 8,
              label: "Agustus"
          }, {
              value: 9,
              label: "September"
          }, {
              value: 10,
              label: "Oktober"
          }, {
              value: 11,
              label: "November"
          }, {
              value: 12,
              label: "Desember"
          }];
          return (0,
          a.jsxs)("div", {
              className: "relative",
              children: [(0,
              a.jsxs)("div", {
                  className: "w-full ".concat(c ? "h-100 absolute" : "h-20", " transition-all duration-300 p-2 bg-[#15406A]"),
                  children: [(0,
                  a.jsxs)("div", {
                      className: "flex justify-between items-center",
                      children: [(0,
                      a.jsx)("a", {
                          href: "https://temank3.kemnaker.go.id",
                          children: (0,
                          a.jsx)("img", {
                              src: "https://temank3.kemnaker.go.id/public/themes/website/asset/img/logo.png",
                              alt: "logo",
                              className: "w-[170px] h-[58px]"
                          })
                      }), (0,
                      a.jsx)("div", {
                          className: "sm:block hidden sm:px-5 px-0",
                          children: (0,
                          a.jsxs)("ul", {
                              className: "flex",
                              children: [(0,
                              a.jsxs)("li", {
                                  className: "flex items-center px-4 py-2 gap-1",
                                  children: [(0,
                                  a.jsx)(n.xng, {
                                      className: "text-lg text-white"
                                  }), (0,
                                  a.jsx)("a", {
                                      href: "https://temank3.kemnaker.go.id",
                                      className: "block text-white",
                                      children: "BERANDA"
                                  })]
                              }), (0,
                              a.jsxs)("li", {
                                  className: "flex items-center px-4 py-2 gap-1",
                                  children: [(0,
                                  a.jsx)(n.wQ2, {
                                      className: "text-lg text-white"
                                  }), (0,
                                  a.jsx)("a", {
                                      href: "https://temank3.kemnaker.go.id/page/flowchart",
                                      className: "block text-white",
                                      children: "FLOW CHART LAYANAN"
                                  })]
                              }), (0,
                              a.jsx)("li", {
                                  className: "flex items-center px-4 py-2 gap-1",
                                  children: (0,
                                  a.jsx)("a", {
                                      href: "https://temank3.kemnaker.go.id/page/news",
                                      className: "block text-white",
                                      children: "INFO & ARTIKEL"
                                  })
                              }), (0,
                              a.jsxs)("li", {
                                  className: "flex items-center px-4 py-2 gap-1",
                                  children: [(0,
                                  a.jsx)(n.Mp$, {
                                      className: "text-lg text-white"
                                  }), (0,
                                  a.jsx)("a", {
                                      href: "https://temank3.kemnaker.go.id/page/perundangan",
                                      className: "block text-white",
                                      children: "DOKUMEN K3"
                                  })]
                              }), (0,
                              a.jsxs)("li", {
                                  className: "flex items-center px-4 py-2 gap-1",
                                  children: [(0,
                                  a.jsx)(n.Xws, {
                                      className: "text-lg text-white"
                                  }), (0,
                                  a.jsx)("a", {
                                      href: "https://temank3.kemnaker.go.id/page/kontak",
                                      className: "block text-white",
                                      children: "HUBUNGI KAMI"
                                  })]
                              }), (0,
                              a.jsx)("li", {
                                  className: "flex items-center px-4 py-2 gap-1",
                                  children: (0,
                                  a.jsx)("a", {
                                      href: "https://temank3.kemnaker.go.id/login",
                                      className: "block text-white",
                                      children: "LOGIN"
                                  })
                              })]
                          })
                      }), (0,
                      a.jsx)("button", {
                          onClick: ()=>{
                              o(!c)
                          }
                          ,
                          className: "border sm:hidden border-[#FFFFFF8C] focus:border-2 p-2 rounded-md w-16 flex items-center justify-center",
                          children: (0,
                          a.jsx)(s.Bbf, {
                              className: "text-[#FFFFFF8C]",
                              fontSize: 30
                          })
                      })]
                  }), (0,
                  a.jsx)("div", {
                      className: "".concat(c ? "block" : "hidden"),
                      id: "dropdown-menu",
                      children: (0,
                      a.jsxs)("ul", {
                          children: [(0,
                          a.jsxs)("li", {
                              className: "flex items-center px-4 py-2 gap-1",
                              children: [(0,
                              a.jsx)(n.xng, {
                                  className: "text-lg text-white"
                              }), (0,
                              a.jsx)("a", {
                                  href: "https://temank3.kemnaker.go.id",
                                  className: "block text-white",
                                  children: "BERANDA"
                              })]
                          }), (0,
                          a.jsxs)("li", {
                              className: "flex items-center px-4 py-2 gap-1",
                              children: [(0,
                              a.jsx)(n.wQ2, {
                                  className: "text-lg text-white"
                              }), (0,
                              a.jsx)("a", {
                                  href: "https://temank3.kemnaker.go.id/page/flowchart",
                                  className: "block text-white",
                                  children: "FLOW CHART LAYANAN"
                              })]
                          }), (0,
                          a.jsx)("li", {
                              className: "flex items-center px-4 py-2 gap-1",
                              children: (0,
                              a.jsx)("a", {
                                  href: "https://temank3.kemnaker.go.id/page/news",
                                  className: "block text-white",
                                  children: "INFO & ARTIKEL"
                              })
                          }), (0,
                          a.jsxs)("li", {
                              className: "flex items-center px-4 py-2 gap-1",
                              children: [(0,
                              a.jsx)(n.Mp$, {
                                  className: "text-lg text-white"
                              }), (0,
                              a.jsx)("a", {
                                  href: "https://temank3.kemnaker.go.id/page/perundangan",
                                  className: "block text-white",
                                  children: "DOKUMEN K3"
                              })]
                          }), (0,
                          a.jsxs)("li", {
                              className: "flex items-center px-4 py-2 gap-1",
                              children: [(0,
                              a.jsx)(n.Xws, {
                                  className: "text-lg text-white"
                              }), (0,
                              a.jsx)("a", {
                                  href: "https://temank3.kemnaker.go.id/page/kontak",
                                  className: "block text-white",
                                  children: "HUBUNGI KAMI"
                              })]
                          }), (0,
                          a.jsx)("li", {
                              className: "flex items-center px-4 py-2 gap-1",
                              children: (0,
                              a.jsx)("a", {
                                  href: "https://temank3.kemnaker.go.id/login",
                                  className: "block text-white",
                                  children: "LOGIN"
                              })
                          })]
                      })
                  })]
              }), (0,
              a.jsx)("div", {
                  className: "sm:px-20 px-4 p-4 ".concat(c ? "pt-24" : "", " "),
                  children: (null == r ? void 0 : r.length) > 0 ? (0,
                  a.jsxs)(a.Fragment, {
                      children: [(0,
                      a.jsx)("h1", {
                          className: "text-[26px] text-[#5a5a5a] text-center font-semibold",
                          children: "Hasil Scan QRCODE Personel"
                      }), (0,
                      a.jsxs)("div", {
                          className: "border-4 sm:border-[7px] sm:rounded-xl border-[#15406A] rounded-lg bg-white mt-2",
                          children: [(0,
                          a.jsx)("div", {
                              className: "bg-[#15406A] w-full p-1 mt-2",
                              children: (0,
                              a.jsx)("h1", {
                                  className: "text-center font-semibold text-xl text-white",
                                  children: "BIODATA PERSONEL"
                              })
                          }), (0,
                          a.jsxs)("div", {
                              className: "flex flex-col items-center mt-2 mb-4",
                              children: [(0,
                              a.jsx)("img", {
                                  alt: "photo-user",
                                  src: null == d ? void 0 : d.photo,
                                  className: "w-[150px] h-[200px]"
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Nama: ", null == d ? void 0 : d.name]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Tempat Lahir: ", null == d ? void 0 : d.birth_place]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Tanggal Lahir: ", (10 > new Date(null == d ? void 0 : d.birth_date).getDate() ? "0" + new Date(null == d ? void 0 : d.birth_date).getDate() : new Date(null == d ? void 0 : d.birth_date).getDate()) + " " + (null == m ? void 0 : null === (t = m.find(e=>e.value == new Date(null == d ? void 0 : d.birth_date).getMonth() + 1)) || void 0 === t ? void 0 : t.label) + " " + new Date(null == d ? void 0 : d.birth_date).getFullYear()]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Jenis Personel: ", (null == d ? void 0 : d.personel_type) || "-"]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Jenis Alat: ", (null == d ? void 0 : d.tool_type) || "-"]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Klasifikasi: ", (null == d ? void 0 : d.clasification) || "-"]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Kelas: ", null == d ? void 0 : d.class]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["No. Registrasi: ", null == d ? void 0 : d.regis_no]
                              }), (0,
                              a.jsxs)("p", {
                                  className: "font-bold text-sm mt-1",
                                  children: ["Masa Berlaku: ", (10 > new Date(null == d ? void 0 : d.expired_at).getDate() ? "0" + new Date(null == d ? void 0 : d.expired_at).getDate() : new Date(null == d ? void 0 : d.expired_at).getDate()) + " " + (null == m ? void 0 : null === (l = m.find(e=>e.value == new Date(null == d ? void 0 : d.expired_at).getMonth() + 1)) || void 0 === l ? void 0 : l.label) + " " + new Date(null == d ? void 0 : d.expired_at).getFullYear()]
                              })]
                          })]
                      })]
                  }) : (0,
                  a.jsx)("div", {
                      className: "bg-red-200 p-2",
                      children: (0,
                      a.jsx)("h1", {
                          className: "text-[28px] text-red-800 text-center font-semibold",
                          children: "Data yang Anda Cari Tidak Terdaftar di Database Teman K3"
                      })
                  })
              }), (0,
              a.jsxs)("div", {
                  className: "mt-2",
                  children: [(0,
                  a.jsxs)("div", {
                      className: "bg-[#15406A] w-full p-2 sm:p-10",
                      children: [(0,
                      a.jsx)("div", {
                          className: "sm:px-20 px-0 sm:flex sm:items-center sm:justify-center",
                          children: (0,
                          a.jsx)("img", {
                              alt: "support",
                              src: "https://temank3.kemnaker.go.id/public/themes/website/asset/img/logofooter1.png",
                              className: "w-full h-100 sm:w-[900px]"
                          })
                      }), (0,
                      a.jsx)("p", {
                          className: "text-white text-center",
                          children: "Jl. Jenderal Gatot Subroto Kav.51, Daerah Khusus Ibukota Jakarta, 12750, Indonesia"
                      })]
                  }), (0,
                  a.jsx)("div", {
                      className: "bg-black w-full p-5",
                      children: (0,
                      a.jsx)("p", {
                          className: "text-white text-center font-semibold",
                          children: "Copyright GG \xa9 2020-2024 Ditjen Binwasnaker & K3, Kemnaker R.I."
                      })
                  }), (0,
                  a.jsx)("div", {
                      className: "bg-white w-full p-7"
                  })]
              })]
          })
      }
  },
  8357: function(e, t, l) {
      "use strict";
      l.d(t, {
          w_: function() {
              return c
          }
      });
      var a = l(7294)
        , s = {
          color: void 0,
          size: void 0,
          className: void 0,
          style: void 0,
          attr: void 0
      }
        , n = a.createContext && a.createContext(s)
        , i = function() {
          return (i = Object.assign || function(e) {
              for (var t, l = 1, a = arguments.length; l < a; l++)
                  for (var s in t = arguments[l])
                      Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s]);
              return e
          }
          ).apply(this, arguments)
      }
        , r = function(e, t) {
          var l = {};
          for (var a in e)
              Object.prototype.hasOwnProperty.call(e, a) && 0 > t.indexOf(a) && (l[a] = e[a]);
          if (null != e && "function" == typeof Object.getOwnPropertySymbols)
              for (var s = 0, a = Object.getOwnPropertySymbols(e); s < a.length; s++)
                  0 > t.indexOf(a[s]) && Object.prototype.propertyIsEnumerable.call(e, a[s]) && (l[a[s]] = e[a[s]]);
          return l
      };
      function c(e) {
          return function(t) {
              return a.createElement(o, i({
                  attr: i({}, e.attr)
              }, t), function e(t) {
                  return t && t.map(function(t, l) {
                      return a.createElement(t.tag, i({
                          key: l
                      }, t.attr), e(t.child))
                  })
              }(e.child))
          }
      }
      function o(e) {
          var t = function(t) {
              var l, s = e.attr, n = e.size, c = e.title, o = r(e, ["attr", "size", "title"]), d = n || t.size || "1em";
              return t.className && (l = t.className),
              e.className && (l = (l ? l + " " : "") + e.className),
              a.createElement("svg", i({
                  stroke: "currentColor",
                  fill: "currentColor",
                  strokeWidth: "0"
              }, t.attr, s, o, {
                  className: l,
                  style: i(i({
                      color: e.color || t.color
                  }, t.style), e.style),
                  height: d,
                  width: d,
                  xmlns: "http://www.w3.org/2000/svg"
              }), c && a.createElement("title", null, c), e.children)
          };
          return void 0 !== n ? a.createElement(n.Consumer, null, function(e) {
              return t(e)
          }) : t(s)
      }
  }
}, function(e) {
  e.O(0, [445, 57, 774, 888, 179], function() {
      return e(e.s = 541)
  }),
  _N_E = e.O()
}
]);
